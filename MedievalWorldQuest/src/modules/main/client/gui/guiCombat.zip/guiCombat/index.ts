import mmorpg from 'mmorpg!./mmorpg'

export default mmorpg
