import { RpgClient, RpgModule } from '@rpgjs/client'
import { sprite } from './sprite'
import combatGui from '../gui/combat.vue'
import { sceneMap } from './map'

@RpgModule<RpgClient>({ 
    sprite,
    scenes: {
        map: sceneMap
    },
    gui: [
        combatGui,

    ]
})
export default class RpgClientEngine {}